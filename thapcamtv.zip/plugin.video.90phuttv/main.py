from urllib.parse import urlencode, parse_qsl
import sys, xbmcgui, xbmcplugin, requests, os, re, json
import xbmcaddon, xbmc, urllib.request
import shutil, zipfile
addon = xbmcaddon.Addon()


base_url = sys.argv[0]
HANDLE = int(sys.argv[1])
ADDON_PATH = addon.getAddonInfo('path')

def get_url(**kwargs):
    return base_url + '?' + urlencode(kwargs)



def list_link_thapcam(link,name1,logo1,logo2,desc1):
    headers = {
              'accept': '*/*',
              'authority': 'q.thapcamn.xyz',
              'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
              'origin': 'https://xem.thapcam.pro',
              'referer': 'https://xem.thapcam.pro/',
              'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
              'sec-ch-ua-mobile': '?1',
              'sec-ch-ua-platform': '"Android"',
              'sec-fetch-dest': 'empty',
              'sec-fetch-mode': 'cors',
              'sec-fetch-site': 'cross-site',
              'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
              }
    api = 'https://q.thapcamn.xyz/api/match/tc/'+link+'/no/meta'
    data_match = requests.get(url=api, headers=headers).json()
    if data_match['data']['play_urls'] is None:
        logo = os.path.join(ADDON_PATH, 'icon.comingsoon.jpg')
        name = 'Chưa có link'
        match = 'http://127.0.0.1'
        fanart = ""
        desc = "Chưa có link hoặc trận đấu chưa diễn ra!"
        list_item = xbmcgui.ListItem(name)
        list_item.setArt({'thumb': logo, 'poster': logo, 'banner': logo, 'icon': logo, 'fanart': fanart})
        list_item.setInfo(type='video', infoLabels={'title': name,'sorttitle': name,'plot': desc})
        list_item.setProperty("IsPlayable", 'true')
        xbmcplugin.addDirectoryItem(HANDLE, match, list_item, isFolder=False)
    else:
        lv='ppp'
        for item in data_match['data']['play_urls']:
        	if 'Full' in item['name']:
        		lv='Full'
        		break
        	elif 'HD' in item['name']:
        		lv='HD'
        for item in data_match['data']['play_urls']:
            if lv in item['name']:
	            logo = logo1
	            name = name1 +' | '+item['name']
	            match = item['url']+'|Referer=https://i.fdcdn.xyz/'
	            fanart = ""
	            desc = desc1
	            list_item = xbmcgui.ListItem(name)
	            list_item.setArt({'thumb': logo, 'poster': logo, 'banner': logo, 'icon': logo, 'fanart': fanart})
	            list_item.setInfo(type='video', infoLabels={'title': name,'sorttitle': name,'plot': desc})
	            list_item.setProperty("IsPlayable", 'true')
	            xbmcplugin.addDirectoryItem(HANDLE, match, list_item, isFolder=False)
	            break
#    xbmcplugin.endOfDirectory(HANDLE)



def list_thapcam():
    headers = {
              'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
              'Accept': '*/*',
              'Referer': 'https://xem.thapcam.pro/',
              'sec-ch-ua-mobile': '?1',
              'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
              'sec-ch-ua-platform': '"Android"',
              }
    from datetime import datetime
    api = 'https://q.thapcamn.xyz/api/match/live/'
    data_match = requests.get(url=api, headers=headers).json()
    trash = ['canceled', 'finished','delay']
    for item in data_match['data']:
        if item['match_status'] not in trash and item['is_live']:
            logo = item['tournament']['logo']
            logo_home=item['home']['logo']
            if not logo:
                logo = os.path.join(ADDON_PATH, 'icon.thapcam.jpg')
            timestampp = str(item['timestamp']).replace('0000', '0')
            time = datetime.fromtimestamp(int(timestampp)).strftime('%Hh%M-%d/%m')
            blv = '| BLV: ' + item['commentators'][0]['name'] if item['commentators'] and item['commentators'][0]['name'] else ''
            sport_type=item['sport_type']
            name = f"{sport_type} | {time}: {item['name']} {blv}"
            match = item['id']
            fanart = ""
            desc = item['tournament']['name']
            list_link_thapcam(match,name,logo_home,logo,desc)

    xbmcplugin.endOfDirectory(HANDLE)




if __name__ == '__main__':
    list_thapcam()